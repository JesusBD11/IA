package PracIA;

import aima.search.framework.GoalTest;

/**
 * Created by Javier, Jesus & Mauro
 */
public class GoalTestS implements aima.search.framework.GoalTest {

    public boolean isGoalState(Object state){

        return((Estado) state).is_goal();
    }
}
