package PracIA;

import aima.search.framework.SuccessorFunction;
import aima.search.framework.Successor;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Javier, Jesus & Mauro
 */
public class SuccesorFunction implements SuccessorFunction{

    public List getSuccessors(Object state){
        ArrayList retval = new ArrayList();
        Estado config = (Estado) state;
        Estado new_state = config.copyEstado();

        for(int i = 0; i< Estado.NUM_SENSORES;++i){

            //Utilizamos el primer conjunto de operadores (solo swap1)
            if (Estado.CONJ_OP == 1) {
                for (int j = 0; j < Estado.NUM_SENSORES + Estado.NUM_CENTROS; ++j) {
                    if (i != j) {
                        boolean b = new_state.swapConexion(i, j);
                        if (b) {
                            retval.add(new Successor(new String("Sensor " + i + " pasa a estar conectado con " + j + " con coste " + new_state.heuristic()), new_state));
                        }
                        new_state = config.copyEstado();
                    }
                }
            }



            //Utilizamos el segundo conjunto de operadores (swap1 + swap2)
            else {
                for (int j = 0; j < Estado.NUM_SENSORES+Estado.NUM_CENTROS; ++j) {
                    if (i != j) {
                        boolean b = false;

                        if (j < Estado.NUM_SENSORES) b = new_state.swapConexion2(i, j);

                        if (b) {
                            retval.add(new Successor(new String("swap conexion de " + i + " con " + j + " con coste " + new_state.heuristic()), new_state));
                        }
                        new_state = config.copyEstado();

                        b = new_state.swapConexion(i, j);
                        if (b) {
                            retval.add(new Successor(new String("Sensor " + i + " pasa a estar conectado con " + j + " con coste " + new_state.heuristic()), new_state));
                        }
                        new_state = config.copyEstado();
                    }
                }
            }
        }


        return retval;


    }
}
