package PracIA;

import IA.Red.CentrosDatos;
import IA.Red.Sensores;

import java.util.ArrayList;
import java.util.Stack;


/**
  *  Created by Javier, Jesus & Mauro on 14/03/21.
  */
public class Estado {


    //Sensores del Problema
    static private Sensores sensores;
    //Centros de datos del problema
    static private CentrosDatos centros;

    //Representa la conexion de salida de un sensor
    private int[] conexionesSensores;

    //Representa el coste de de la transmision del estado
    private double costeTotal;
    //Representa la informacion total transmitida del estado
    private int infoSolucion;
    //Numero de centros usados
    private int centrosUtilizados;


    /*** CONSTANTES ***/
    //Numero de sensores
    public static final int NUM_SENSORES = 100;
    //Numero de centros de datos
    public static final int NUM_CENTROS = 4;
    //Numero de la seed de los centros
    public static int SEED_C = 450;
    //Numero de la seed de los sensores
    public static int SEED_S = 210;


    //Constantes para decidir el metodo de generacion de solucion inicial
    public static final int GENERADOR1 = 1;
    public static final int GENERADOR2 = 2;
    /*
     *   Constante para decidir el conjunto de operadores, si es 1 usa el conjunto de operadores 1,
     *    si es 2 usa el conjunto
     */
    public static final int CONJ_OP = 1;
    //Constante para usar Simulated Anneling
    public static final int SA = 1;
    //Constante para usar Hill Climbing
    public static final int H_CLIMBING = 0;




    /***Funciones Privadas***/
    /*
     *  Pre: -
     *  Post: Devuelve falso si hay ciclos o si la solucion no es valida. Si es valida devuelve cierto y actualiza
     *        correctamente infoSolucion, costeTotal, centrosUtilizados.
     */
    private boolean topologicalSort(){
        costeTotal = 0;
        centrosUtilizados = NUM_CENTROS;

        int [] infoRecibida = new int [NUM_SENSORES+NUM_CENTROS];
        for (int i = 0; i < NUM_SENSORES + NUM_CENTROS; ++i) {
            infoRecibida[i] = 0;
        }

        int[] gradoEntrada =  new int[NUM_SENSORES+NUM_CENTROS];
        for(int i = 0; i < NUM_SENSORES+NUM_CENTROS; ++i){gradoEntrada[i] = 0;}

        for (int i = 0; i < NUM_SENSORES; ++i){
            ++gradoEntrada[conexionesSensores[i]];
            if(conexionesSensores[i] < NUM_SENSORES && gradoEntrada[i] > 3 || conexionesSensores[i] >= NUM_SENSORES && gradoEntrada[i] > 25) return false;
        }

        Stack<Integer> S = new Stack<Integer>();
        ArrayList<Integer> L = new ArrayList<Integer>();

        for(int i = 0; i < NUM_SENSORES+NUM_CENTROS; ++i){
            if (gradoEntrada[i] == 0){
                S.push(i);
            }
        }

        while(!S.empty()){
            int u = S.pop();
            L.add(u);

            //Es sensor
            if(u < NUM_SENSORES) {
                int capacidadActual = (int) sensores.get(u).getCapacidad();
                if (capacidadActual * 2 < infoRecibida[u]) infoRecibida[u] = capacidadActual * 2;

                if (--gradoEntrada[conexionesSensores[u]] == 0) S.push(conexionesSensores[u]);

                //Posicion del sensor actual
                int sensorX = sensores.get(u).getCoordX();
                int sensorY = sensores.get(u).getCoordY();

                //Posicion de destino
                int destinoX = 0;
                int destinoY = 0;

                //El destino es un centro
                if (conexionesSensores[u] >= NUM_SENSORES) {
                    destinoX = centros.get(conexionesSensores[u] - NUM_SENSORES).getCoordX();
                    destinoY = centros.get(conexionesSensores[u] - NUM_SENSORES).getCoordY();
                }

                //El destino es un sensor
                else {
                    destinoX = sensores.get(conexionesSensores[u]).getCoordX();
                    destinoY = sensores.get(conexionesSensores[u]).getCoordY();
                }

                double distancia = squaredDistance(sensorX, destinoX, sensorY, destinoY);
                costeTotal += distancia * (infoRecibida[u] + sensores.get(u).getCapacidad());

                infoRecibida[conexionesSensores[u]] += infoRecibida[u] + capacidadActual;
            }
        }

        int infoTotal = 0;
        for (int i = NUM_SENSORES; i < NUM_SENSORES + NUM_CENTROS; ++i) {
            if (infoRecibida[i] <= 150) infoTotal += infoRecibida[i];
            else infoTotal += 150;
            if (infoRecibida[i] == 0) --centrosUtilizados;
        }

        infoSolucion = infoTotal;
        return (L.size() == NUM_SENSORES + NUM_CENTROS);
    }

    /*
     *  Todos los sensores van directamente a un centro mientras sea posible.
     *  Una vez no se pueden seguir conectado comenzamos a conectar el resto de sensores a otros sensores
     */
    private void generadorSolucionInicial1(){
        int countSensor = 0;
        for (int i = 0; i<NUM_SENSORES; i++){
            if (i <= NUM_CENTROS * 25) conexionesSensores[i] = NUM_SENSORES + (i % NUM_CENTROS);
            else {
                conexionesSensores[i] = countSensor;
                ++countSensor;
            }
        }
    }

    /*
     *  Cada sensor se conecta al siguiente sensor segun el indice en el que se encuentran.
     *  El ultimo sensor se conecta al primer centro.
     */
    private void generadorSolucionInicial2(){
        int countSensor = 0;
        for (int i = 0; i<NUM_SENSORES; i++){
            conexionesSensores[i] = i+1;
        }
    }

    /*
     *  PRE: -
     *  POST: Devuelve la distancia entre el punto (x1,y1) y el punto (x2,y2) al cuadrado
     */
    private double squaredDistance(float x1, float x2, float y1, float y2){
        double a =  x1 - x2;
        double b =  y1 - y2;
        a = a * a;
        b = b * b;
        return a+b;
    }



    /***Getters & Setters***/
    public Sensores getS(){return sensores;}
    public CentrosDatos getC(){return centros;}
    public double getInfo(){return infoSolucion;}
    public double getCoste(){return costeTotal;}
    public int getCentrosUtilizados(){return centrosUtilizados;}
    public int[] getConexionesSensores(){return conexionesSensores;}
    public void setConexiones(int [] aux) {conexionesSensores = aux;}



    /*** Constructor ***/
    //Contructor vacio
    public Estado() {
        conexionesSensores = new int[NUM_SENSORES];
    }

    /*
     *  PRE: i = GENERADOR1 o GENERADOR2
     *  POST: Genera un estado con una solocion inicial creada con el
     *        generador seleccionado.
     */
    public Estado(int i) {
        sensores = new Sensores(NUM_SENSORES,SEED_S);
        centros = new CentrosDatos(NUM_CENTROS,SEED_C);
        conexionesSensores = new int[NUM_SENSORES];

        if(i == GENERADOR1) generadorSolucionInicial1();
        if(i == GENERADOR2) generadorSolucionInicial2();

        topologicalSort();

    }



    /***Funciones del estado***/
    /*
     *  PRE: 0 <= j < NUM_SENSORES + NUM_CENTROS, 0 <= i < NUM_SENSORES, i != j
     *  POST: Cambia el destino de la arista de salida del sensor i al destino j
     */
    public boolean swapConexion(int i, int j){
        //Modifica la arista del sensor i
        int conexionPrevia = conexionesSensores[i];
        conexionesSensores[i] = j; //Numero random
        if(!topologicalSort()) {
            conexionesSensores[i] = conexionPrevia;
            return false;
        }
        return true;
    }

    /*
     *  PRE: 0 <= j < NUM_SENSORES, 0 <= i < NUM_SENSORES, i != j, no deben existir conexiones entre i y j
     *  POST: Cambia el destino de la arista de salida del sensor i por el destino de la arista de salida de j.
     *        Cambia el destino de la arista de salida del sensor j por el destino de la arista de salida de i.
     */
    public boolean swapConexion2(int i, int j){
        //Modifica la arista del sensor i
        int conexionPrevia1 = conexionesSensores[i];
        int conexionPrevia2 = conexionesSensores[j];
        conexionesSensores[i] = conexionPrevia2;
        conexionesSensores[j] = conexionPrevia1;
        if(!topologicalSort()) {
            conexionesSensores[i] = conexionPrevia1;
            conexionesSensores[j] = conexionPrevia2;
            return false;
        }
        return true;
    }

    /* Heuristic function */
    public double heuristic(){
        return costeTotal/10000.0 - infoSolucion;
        //return -infoSolucion;
        //return costeTotal;


    }

     /* Goal test */
     public boolean is_goal(){
         return false;
     }

     /* Copia un estado*/
     Estado copyEstado(){
        int[] aux = new int[NUM_SENSORES];
        for (int i = 0; i<NUM_SENSORES; ++i) {aux[i] = this.conexionesSensores[i];}
        Estado copia = new Estado();
        copia.conexionesSensores = aux;
        copia.infoSolucion = this.infoSolucion;
        copia.costeTotal = this.costeTotal;
        return copia;
    }

}
