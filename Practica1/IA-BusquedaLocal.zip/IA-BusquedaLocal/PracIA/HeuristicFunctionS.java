package PracIA;

/**
 * Created by Javier, Jesus & Mauro
 */

import aima.search.framework.HeuristicFunction;

public class HeuristicFunctionS implements aima.search.framework.HeuristicFunction {

    public double getHeuristicValue(Object n){

        return ((Estado) n).heuristic();
    }
}
