import PracIA.Estado;
import PracIA.GoalTestS;
import PracIA.HeuristicFunctionS;
import PracIA.SuccesorFunction;
import aima.search.framework.GraphSearch;
import aima.search.framework.Problem;
import aima.search.framework.Search;
import aima.search.framework.SearchAgent;
import aima.search.informed.AStarSearch;
import aima.search.informed.HillClimbingSearch;
import aima.search.informed.SimulatedAnnealingSearch;

import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class Main {

    public static void main(String[] args) throws Exception{
        //int[] seeds = {1532,5695,4334,6552,1987,1181};
        //for(int k = 0; k < 6; ++k) {
            //Estado.SEED_C = seeds[k];
            //Estado.SEED_S = seeds[k];

            //Selecionamos tipo de generador de solucion inicial
            Estado estado = new Estado(Estado.GENERADOR1);
            //Selecionamos el algoritmo a utilizar
            int algoritmoAUsar = Estado.SA;

            Search alg = null;

            long[] time = new long[5];
            double[] heuristica = new double[5];
            long[] costeInstalacion = new long[5];

            System.out.println("Coste Inicial: " + estado.heuristic());

            for (int i = 0; i < 5; ++i) {
                //Iniciamos el cronometro
                time[i] = System.currentTimeMillis();


                // Create the Problem object
                Problem p = new Problem(estado,
                        new SuccesorFunction(),
                        new GoalTestS(),
                        new HeuristicFunctionS());

                // Instantiate the search algorithm
                if(algoritmoAUsar == Estado.SA) alg = new SimulatedAnnealingSearch(10000, 10, 5, 0.1);
                else alg = new HillClimbingSearch();

                // Instantiate the SearchAgent object
                SearchAgent agent = new SearchAgent(p, alg);

                //Apagamos el cronometro
                time[i] = System.currentTimeMillis() - time[i];

                // We print the results of the search
                System.out.println();
                if(algoritmoAUsar == Estado.H_CLIMBING) printActions(agent.getActions());
                printInstrumentation(agent.getInstrumentation());

                Estado e = (Estado) alg.getGoalState();
                heuristica[i] = e.heuristic();
                costeInstalacion[i] = (long) e.getCoste();
            }

            //Variables para acumular la suma total
            long min = 1000000000;
            long max = 0;
            long tiempoTotal = 0;
            double heuristicaTotal = 0;
            long costeInstalacionTotal = 0;

            //Numero de iteraciones para obtener la media
            int numeroIteraciones = 5;

            //Calculamos la media del tiempo y heuristica
            for (int i = 0; i < numeroIteraciones; ++i) {
                if (min > time[i]) min = time[i];
                if(max < time[i]) max = time[i];
                tiempoTotal += time[i];
                heuristicaTotal += heuristica[i];
                costeInstalacionTotal += costeInstalacion[i];
            }
            tiempoTotal = tiempoTotal - (min + max);
            tiempoTotal /= numeroIteraciones - 2;
            heuristicaTotal /= numeroIteraciones;
            costeInstalacionTotal /= numeroIteraciones;


            //Escribimos el tiempo total
            System.out.println();
            System.out.println(tiempoTotal + " ms");

            //Escribimos la heuristica total
            System.out.println();
            System.out.println("Heuristica total: " + heuristicaTotal);


            //Escribimos el coste de instalacion del estado final
            System.out.println();
            Estado e = (Estado) alg.getGoalState();
            System.out.println("Coste de instalacion final: " + costeInstalacionTotal);
            //System.out.println("Info de instalacion final: " + e.getInfo());
            System.out.println();
            System.out.println("Centros Utilizados: " + e.getCentrosUtilizados());


        //}

    }

    private static void printInstrumentation(Properties properties) {
        Iterator keys = properties.keySet().iterator();
        while (keys.hasNext()) {
            String key = (String) keys.next();
            String property = properties.getProperty(key);
            System.out.println(key + " : " + property);
        }

    }
    
    private static void printActions(List actions) {
        for (int i = 0; i < actions.size(); i++) {
            String action = (String) actions.get(i);
            System.out.println(action);
        }
    }
    
}
